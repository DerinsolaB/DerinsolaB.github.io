
//Primitive Paint
//Derinsola Bolaji
//2nd October 2023
//
//Global Variables
let number1 = 0;
let number2 = 0;
let number3 = 0;
let number4 = 0;
let number5 = 0;
let number6 = 0;
let number7 = 0;
let number8 = 0;
let number11 = 0;


function setup() {
  //Creating Canvas
  createCanvas(windowWidth, windowHeight);
  background(220);
  rectMode(CENTER);
}

//calling built-in global variable "name" in a function
function name(){
  //Writing my name in the top corner of the screen
  textSize(32);
  textFont("Times New Roman");
  text("Derinsola", 13, 36 );

}

function keyPressed(){
  //Creating the output for when keys are pressed 
  if(key==="a"){
    rect(mouseX,mouseY,200,100);
  }
  else if(key==="s"){
    ellipse(mouseX,mouseY,100,100);
  }
  else if(key==="d"){
    square(mouseX,mouseY,100);
  }
  else if (key==="w"){
    number1 = Math.floor(Math.random() * 255);
    number2 = Math.floor(Math.random() * 255);
    number3 = Math.floor(Math.random() * 255);
    fill(number1,number2,number3);
  }
}

function clearCanvas(){
  //Creating response to the space bar being pressed 
  if (keyCode === 32){
    createCanvas(windowWidth, windowHeight);
    background(220);
  }
}

function pickNumber(){
  //Creating rectangle and randomly selecting colors
  if (number7 < 50){
    number4 = Math.floor(Math.random() * 255);
    number5 = Math.floor(Math.random() * 255);
    number6 = Math.floor(Math.random() * 255);
    fill(number4,number5,number6);
    rect(windowWidth/2, windowHeight/2,number8,number11);
    number8 = number8 + 2;
    number11 = number11 + 1;
    number7 =number7 + 1;
  }
  else if (number7 >= 50){
    number8 = 100;
    number11 = 50;
    number7 = 0;
  }
}

function draw() {
//Calling functions to run in output
  clearCanvas();
  name();
  pickNumber();
}