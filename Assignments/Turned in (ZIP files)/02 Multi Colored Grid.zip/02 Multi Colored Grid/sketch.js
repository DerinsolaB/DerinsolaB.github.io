// Multi Colored Grid
// Derinsola Bolaji
//5th October 2023
//
// Global Variables
let squaresize = 18;

function setup() {
  createCanvas(windowWidth, windowHeight);
  //Presetting the code to listen for mousepressed
  document.addEventListener("contextmenu", event => event.preventDefault());
  drawGrid();
}

function draw() {
  background(120);
  //Calling the drawGrid function
  drawGrid();
}

function drawGrid(){
  background(120);
  //Creating squares/grid as well as random colors
  for(let x = 0; x < width-squaresize; x += squaresize){
    for(let y = 0; y < height-squaresize; y+= squaresize){
      fill(color(random(100),random(256),random(256)));
      rect(x,y,squaresize,squaresize);
    }
  }
}

function mousePressed(){
  //Setting the left mouse button to decrease grid
  if(mouseButton === LEFT){
    squaresize -= 5;
  }
  else if(mouseButton === RIGHT){
    //Setting the right mouse button to increase grid 
    squaresize += 5;
  }
}
